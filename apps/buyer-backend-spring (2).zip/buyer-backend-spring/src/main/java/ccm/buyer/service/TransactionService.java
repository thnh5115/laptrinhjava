package ccm.buyer.service;

import ccm.buyer.entity.Transaction;
import ccm.buyer.entity.TrStatus;
import java.util.List;

public interface TransactionService {
    Transaction getById(Long id);
    List<Transaction> getAll();
    List<Transaction> getByBuyer(Long buyerId);
    List<Transaction> getByStatus(TrStatus status);
    Transaction updateStatus(Long id, TrStatus status);
}
