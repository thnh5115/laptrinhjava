package ccm.buyer.dto.response;

import ccm.buyer.entity.ListingStatus;
import ccm.buyer.entity.ListingType;
import java.time.LocalDateTime;

public record ListingResponse(
    Long id,
    Long creditId,
    ListingType type,
    Double price,
    Integer availableQty,
    ListingStatus status,
    LocalDateTime createdAt,
    LocalDateTime updatedAt
) {}
