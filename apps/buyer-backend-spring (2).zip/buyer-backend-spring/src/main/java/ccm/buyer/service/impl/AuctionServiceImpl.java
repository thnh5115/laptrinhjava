package ccm.buyer.service.impl;

import ccm.buyer.entity.*;
import ccm.buyer.repository.*;
import ccm.buyer.service.AuctionService;
import ccm.buyer.service.NotificationService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class AuctionServiceImpl implements AuctionService {

    private final AuctionRepository auctionRepo;
    private final BidRepository bidRepo;
    private final NotificationService notifyService;

    @Override
    @Transactional
    public Bid placeBid(Long buyerId, Long auctionId, Double bidPrice) {
        Auction auction = auctionRepo.findById(auctionId)
                .orElseThrow(() -> new RuntimeException("Auction not found"));

        if (bidPrice < auction.getStartPrice() + auction.getStepPrice())
            throw new IllegalArgumentException("Bid price too low");

        Bid bid = Bid.builder()
                .auction(auction)
                .buyerId(buyerId)
                .bidPrice(bidPrice)
                .status(BidStatus.LEADING)
                .createdAt(LocalDateTime.now())
                .build();

        bidRepo.save(bid);
        notifyService.notifyBuyer(buyerId, "Bid placed successfully at " + bidPrice);
        return bid;
    }
}
