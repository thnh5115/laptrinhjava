package ccm.buyer.repository;

import ccm.buyer.entity.CarbonCredit;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CarbonCreditRepository extends JpaRepository<CarbonCredit, Long> {}
