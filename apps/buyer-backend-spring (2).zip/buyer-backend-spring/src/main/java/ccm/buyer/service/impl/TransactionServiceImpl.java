package ccm.buyer.service.impl;

import ccm.buyer.dto.request.CreateTransactionRequest;
import ccm.buyer.dto.response.TransactionResponse;
import ccm.buyer.entity.*;
import ccm.buyer.exception.NotFoundException;
import ccm.buyer.repository.CreditOrderRepository;
import ccm.buyer.repository.TransactionRepository;
import ccm.buyer.service.TransactionService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class TransactionServiceImpl implements TransactionService {

    private final TransactionRepository txRepo;
    private final CreditOrderRepository orderRepo;

    @Override
    public TransactionResponse create(CreateTransactionRequest req) {
        CreditOrder order = orderRepo.findById(req.orderId())
                .orElseThrow(() -> new NotFoundException("Order not found"));

        Transaction tx = Transaction.builder()
                .order(order)
                .type(req.type())
                .status(TransactionStatus.PENDING)
                .amount(req.amount())
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();

        return map(txRepo.save(tx));
    }

    @Override
    public TransactionResponse get(Long id) {
        return txRepo.findById(id).map(this::map)
                .orElseThrow(() -> new NotFoundException("Transaction not found"));
    }

    @Override
    public Page<TransactionResponse> list(Pageable pageable) {
        return txRepo.findAll(pageable).map(this::map);
    }

    @Override
    public Page<TransactionResponse> listByOrder(Long orderId, Pageable pageable) {
        return txRepo.findByOrder_Id(orderId, pageable).map(this::map);
    }

    @Override
    public Page<TransactionResponse> listByType(TransactionType type, Pageable pageable) {
        return txRepo.findByType(type, pageable).map(this::map);
    }

    @Override
    public Page<TransactionResponse> listByStatus(TransactionStatus status, Pageable pageable) {
        return txRepo.findByStatus(status, pageable).map(this::map);
    }

    private TransactionResponse map(Transaction t) {
        return new TransactionResponse(
                t.getId(), t.getOrder().getId(), t.getType(), t.getStatus(),
                t.getAmount(), t.getCreatedAt(), t.getUpdatedAt()
        );
    }
}
