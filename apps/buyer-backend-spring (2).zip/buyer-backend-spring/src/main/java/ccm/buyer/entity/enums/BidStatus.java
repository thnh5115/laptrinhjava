package ccm.buyer.enums;
public enum BidStatus { OPEN, WON, LOST, CANCELLED }
