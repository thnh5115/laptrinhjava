package ccm.buyer.entity;


import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.time.LocalDateTime;

@Entity
@Table(name = "transactions")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Transaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long buyerId;

    private Long listingId;

    private Integer qty;

    private Double amount;



    @Enumerated(EnumType.STRING)
    private TrStatus status;
    


    private LocalDateTime createdAt;



    @PrePersist
    void onCreate() { createdAt = LocalDateTime.now(); }
}
