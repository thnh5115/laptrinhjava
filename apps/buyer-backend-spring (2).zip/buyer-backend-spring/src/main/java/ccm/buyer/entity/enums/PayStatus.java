package ccm.buyer.enums;
public enum PayStatus { INIT, PAID, REFUNDED, FAILED }
