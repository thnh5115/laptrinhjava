package ccm.buyer.controller;

import ccm.buyer.dto.request.UpdateTransactionStatusRequest;
import ccm.buyer.dto.response.TransactionResponse;
import ccm.buyer.entity.Transaction;
import ccm.buyer.entity.TrStatus;
import ccm.buyer.service.TransactionService;
import lombok.RequiredArgsConstructor;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/buyer/transactions")
@RequiredArgsConstructor
public class TransactionController {

    private final TransactionService service;

    @GetMapping
    public ResponseEntity<List<TransactionResponse>> getAll() {
        return ResponseEntity.ok(
                service.getAll().stream()
                        .map(tx -> new TransactionResponse(
                                tx.getId(), tx.getBuyerId(), tx.getListingId(),
                                tx.getQty(), tx.getAmount(), tx.getStatus(), tx.getCreatedAt()
                        ))
                        .toList()
        );
    }

    @PutMapping("/{id}/status")
    public ResponseEntity<TransactionResponse> updateStatus(
            @PathVariable Long id,
            @RequestBody UpdateTransactionStatusRequest req
    ) {
        Transaction tx = service.updateStatus(id, req.status());
        return ResponseEntity.ok(new TransactionResponse(
                tx.getId(), tx.getBuyerId(), tx.getListingId(),
                tx.getQty(), tx.getAmount(), tx.getStatus(), tx.getCreatedAt()
        ));
    }
}
