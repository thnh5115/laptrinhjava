package ccm.buyer.dto.request;

import ccm.buyer.entity.TrStatus;
import jakarta.validation.constraints.NotNull;

public record UpdateTransactionStatusRequest(
    @NotNull TrStatus status
) {}
