package ccm.buyer.dto.response;

import ccm.buyer.entity.TrStatus;
import java.time.LocalDateTime;

public record TransactionResponse(
    Long id,
    Long buyerId,
    Long listingId,
    Integer qty,
    Double amount,
    TrStatus status,
    LocalDateTime createdAt
) {}
