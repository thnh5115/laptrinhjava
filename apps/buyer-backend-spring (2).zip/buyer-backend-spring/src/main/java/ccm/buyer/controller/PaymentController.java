package ccm.buyer.controller;

import ccm.buyer.dto.request.PaymentRequest;
import ccm.buyer.dto.response.PaymentResponse;
import ccm.buyer.entity.Payment;
import ccm.buyer.service.PaymentService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/buyer/pay")
@RequiredArgsConstructor
public class PaymentController {

    private final PaymentService service;

    @PostMapping
    public ResponseEntity<PaymentResponse> pay(@RequestBody PaymentRequest req) {
        Payment p = service.processPayment(req.trId(), req.method(), req.amount());
        return ResponseEntity.ok(new PaymentResponse(
                p.getId(), p.getTrId(), p.getMethod(),
                p.getStatus(), p.getRef(), p.getAmount(),
                p.getCreatedAt()
        ));
    }
}
