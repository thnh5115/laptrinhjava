package ccm.buyer.dto.response;

import ccm.buyer.entity.PayStatus;
import java.time.LocalDateTime;

public record PaymentResponse(
    Long id,
    Long trId,
    String method,
    PayStatus status,
    String ref,
    Double amount,
    LocalDateTime createdAt
) {}
