package ccm.buyer.enums;
public enum ListingType { FIXED_PRICE, AUCTION }
