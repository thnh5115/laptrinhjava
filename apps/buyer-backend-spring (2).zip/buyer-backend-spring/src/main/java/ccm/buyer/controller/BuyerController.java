package ccm.buyer.controller;

import ccm.buyer.dto.request.DirectBuyRequest;
import ccm.buyer.dto.response.TransactionResponse;
import ccm.buyer.entity.Transaction;
import ccm.buyer.service.BuyerService;

import lombok.RequiredArgsConstructor;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;



@RestController
@RequestMapping("/buyer")
@RequiredArgsConstructor
public class BuyerController {

    private final BuyerService service;

    @PostMapping("/purchase")
    public ResponseEntity<TransactionResponse> directBuy(@RequestBody DirectBuyRequest req) {
        Transaction tx = service.directBuy(req.buyerId(), req.listingId(), req.qty());
        return ResponseEntity.ok(new TransactionResponse(
                tx.getId(),
                tx.getBuyerId(),
                tx.getListingId(),
                tx.getQty(),
                tx.getAmount(),
                tx.getStatus(),
                tx.getCreatedAt()
        ));
    }
}
