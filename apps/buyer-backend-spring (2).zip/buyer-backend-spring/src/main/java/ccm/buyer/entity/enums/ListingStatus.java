package ccm.buyer.enums;
public enum ListingStatus { DRAFT, PUBLISHED, SOLD, CANCELLED }
