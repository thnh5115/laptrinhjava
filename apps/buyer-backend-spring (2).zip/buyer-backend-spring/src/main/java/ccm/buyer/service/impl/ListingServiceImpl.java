package ccm.buyer.service.impl;

import ccm.buyer.entity.Listing;
import ccm.buyer.entity.ListingStatus;
import ccm.buyer.repository.ListingRepository;
import ccm.buyer.service.ListingService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ListingServiceImpl implements ListingService {

    private final ListingRepository repo;

    @Override
    public List<Listing> getAll() {
        return repo.findAll();
    }

    @Override
    public Listing validateOpen(Long id) {
        Listing l = repo.findById(id)
                .orElseThrow(() -> new RuntimeException("Listing not found"));
        if (l.getStatus() != ListingStatus.OPEN)
            throw new IllegalStateException("Listing not available for purchase");
        return l;
    }

    @Override
    @Transactional
    public void reserve(Long id, int qty) {
        Listing l = validateOpen(id);
        if (l.getAvailableQty() < qty)
            throw new IllegalArgumentException("Not enough credits available");
        l.setAvailableQty(l.getAvailableQty() - qty);
        if (l.getAvailableQty() == 0)
            l.setStatus(ListingStatus.LOCKED);
        repo.save(l);
    }

    @Override
    @Transactional
    public void release(Long id, int qty) {
        Listing l = repo.findById(id).orElseThrow();
        l.setAvailableQty(l.getAvailableQty() + qty);
        if (l.getStatus() == ListingStatus.LOCKED)
            l.setStatus(ListingStatus.OPEN);
        repo.save(l);
    }
}
