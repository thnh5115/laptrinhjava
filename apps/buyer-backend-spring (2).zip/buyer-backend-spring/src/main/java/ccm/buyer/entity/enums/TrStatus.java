package ccm.buyer.enums;
public enum TrStatus { PENDING, COMPLETED, FAILED, CANCELLED }
