package ccm.buyer.service.impl;

import ccm.buyer.dto.request.CreateOrderRequest;
import ccm.buyer.dto.request.UpdateOrderStatusRequest;
import ccm.buyer.dto.response.CreditOrderResponse;
import ccm.buyer.entity.*;
import ccm.buyer.exception.NotFoundException;
import ccm.buyer.repository.BuyerRepository;
import ccm.buyer.repository.CreditOrderRepository;

import ccm.buyer.service.CreditOrderService;

import lombok.RequiredArgsConstructor;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

import java.util.List;


@Service
@RequiredArgsConstructor

public class CreditOrderServiceImpl implements CreditOrderService {

    private final CreditOrderRepository orderRepo;
    private final BuyerRepository buyerRepo;

    @Override
    public OrderResponse create(CreateOrderRequest req) {
        Buyer buyer = buyerRepo.findById(req.buyerId())
                .orElseThrow(() -> new NotFoundException("Buyer not found"));

        CreditOrder order = CreditOrder.builder()
                .buyer(buyer)
                .credits(req.credits())
                .pricePerUnit(req.pricePerUnit())
                .status(OrderStatus.PENDING)
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();

        return map(orderRepo.save(order));
    }

    @Override
    public OrderResponse get(Long id) {
        return orderRepo.findById(id).map(this::map)
                .orElseThrow(() -> new NotFoundException("Order not found"));
    }

    @Override
    public Page<OrderResponse> list(Pageable pageable) {
        return orderRepo.findAll(pageable).map(this::map);
    }

    @Override
    public Page<OrderResponse> listByBuyer(Long buyerId, Pageable pageable) {
        return orderRepo.findByBuyer_Id(buyerId, pageable).map(this::map);
    }

    @Override
    public List<OrderResponse> listByBuyer(Long buyerId) {
        return orderRepo.findByBuyer_Id(buyerId).stream().map(this::map).toList();
    }

    @Override
    public OrderResponse updateStatus(Long id, UpdateOrderStatusRequest req) {
        CreditOrder order = orderRepo.findById(id)
                .orElseThrow(() -> new NotFoundException("Order not found"));
        order.setStatus(req.status());
        order.setUpdatedAt(LocalDateTime.now());
        return map(orderRepo.save(order));
    }

    @Override
    public Page<OrderResponse> listByStatus(OrderStatus status, Pageable pageable) {
        return orderRepo.findByStatus(status, pageable).map(this::map);
    }

    private OrderResponse map(CreditOrder o) {
        return new OrderResponse(
                o.getId(), o.getBuyer().getId(), o.getCredits(), o.getPricePerUnit(),
                o.getStatus(), o.getCreatedAt(), o.getUpdatedAt()
        );
    }
}
