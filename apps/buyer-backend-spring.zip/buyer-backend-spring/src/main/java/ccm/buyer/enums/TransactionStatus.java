package ccm.buyer.enums;

public enum TransactionStatus {
    PENDING,
    SUCCESS,
    FAILED
}
